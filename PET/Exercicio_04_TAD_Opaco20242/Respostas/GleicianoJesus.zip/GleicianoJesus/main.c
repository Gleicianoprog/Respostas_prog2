#include"brasileirao.h"
int main(){
    BRA* camp;
    camp=CriaCamp();
    RealizaCamp(camp);
    FinalizaCamp(camp);
    return 0;
}