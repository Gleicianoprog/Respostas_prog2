#include<stdio.h>
#include <stdlib.h>
//#include<stdlib>
// #define DESTE_TIPO_ float
// #define DESTE_FORMATO_ "f"
#include"ponto_geometrico.h"
#include"ponto_arr.h"
int main(int argc,char **argv){
    //float x,y;
    int qtd;
    qtd=atoi(argv[1]);
    tPontos_arr *p;
    p=inicializarTPontos();
    carregarPontos(p,qtd);
    imprimirPontos(p);
    liberarPontos(p);
    return 0;
}